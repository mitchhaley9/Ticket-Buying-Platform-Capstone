﻿namespace Capstone1._1
{
    partial class frmAdmin_Panel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lblSales = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblUDRemain = new System.Windows.Forms.Label();
            this.lblCLRemain = new System.Windows.Forms.Label();
            this.lblLLRemain = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnGuestLookup = new System.Windows.Forms.Button();
            this.tbGuestLookup = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Customer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TotalCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Confirmation_Number = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Lower_Level_Seats = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Club_Level_Seats = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Upper_Deck_Seats = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnClose = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Rockwell", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Green;
            this.label1.Location = new System.Drawing.Point(41, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(121, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "Total Sales";
            // 
            // lblSales
            // 
            this.lblSales.AutoSize = true;
            this.lblSales.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblSales.Font = new System.Drawing.Font("Rockwell", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSales.ForeColor = System.Drawing.Color.LimeGreen;
            this.lblSales.Location = new System.Drawing.Point(207, 24);
            this.lblSales.Name = "lblSales";
            this.lblSales.Size = new System.Drawing.Size(87, 26);
            this.lblSales.TabIndex = 1;
            this.lblSales.Text = "$Dollas";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblUDRemain);
            this.groupBox1.Controls.Add(this.lblCLRemain);
            this.groupBox1.Controls.Add(this.lblLLRemain);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(46, 79);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(395, 100);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Seats Remaining";
            // 
            // lblUDRemain
            // 
            this.lblUDRemain.AutoSize = true;
            this.lblUDRemain.Location = new System.Drawing.Point(312, 65);
            this.lblUDRemain.Name = "lblUDRemain";
            this.lblUDRemain.Size = new System.Drawing.Size(32, 16);
            this.lblUDRemain.TabIndex = 5;
            this.lblUDRemain.Text = "000";
            // 
            // lblCLRemain
            // 
            this.lblCLRemain.AutoSize = true;
            this.lblCLRemain.Location = new System.Drawing.Point(175, 65);
            this.lblCLRemain.Name = "lblCLRemain";
            this.lblCLRemain.Size = new System.Drawing.Size(32, 16);
            this.lblCLRemain.TabIndex = 4;
            this.lblCLRemain.Text = "000";
            // 
            // lblLLRemain
            // 
            this.lblLLRemain.AutoSize = true;
            this.lblLLRemain.Location = new System.Drawing.Point(26, 65);
            this.lblLLRemain.Name = "lblLLRemain";
            this.lblLLRemain.Size = new System.Drawing.Size(32, 16);
            this.lblLLRemain.TabIndex = 3;
            this.lblLLRemain.Text = "000";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(281, 30);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 16);
            this.label4.TabIndex = 2;
            this.label4.Text = "Upper Deck:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(153, 30);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 16);
            this.label3.TabIndex = 1;
            this.label3.Text = "Club Level:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "Lower Level:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnGuestLookup);
            this.groupBox2.Controls.Add(this.tbGuestLookup);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(447, 79);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(341, 100);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Guest Lookup";
            // 
            // btnGuestLookup
            // 
            this.btnGuestLookup.BackColor = System.Drawing.Color.Blue;
            this.btnGuestLookup.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGuestLookup.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGuestLookup.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnGuestLookup.Location = new System.Drawing.Point(187, 70);
            this.btnGuestLookup.Name = "btnGuestLookup";
            this.btnGuestLookup.Size = new System.Drawing.Size(75, 24);
            this.btnGuestLookup.TabIndex = 12;
            this.btnGuestLookup.Text = "Find";
            this.btnGuestLookup.UseVisualStyleBackColor = false;
            // 
            // tbGuestLookup
            // 
            this.tbGuestLookup.Location = new System.Drawing.Point(187, 39);
            this.tbGuestLookup.Name = "tbGuestLookup";
            this.tbGuestLookup.Size = new System.Drawing.Size(100, 22);
            this.tbGuestLookup.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(18, 45);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(152, 16);
            this.label5.TabIndex = 6;
            this.label5.Text = "Confirmation Number";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Customer,
            this.Email,
            this.TotalCost,
            this.Confirmation_Number,
            this.Lower_Level_Seats,
            this.Club_Level_Seats,
            this.Upper_Deck_Seats});
            this.dataGridView1.Location = new System.Drawing.Point(46, 210);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(742, 150);
            this.dataGridView1.TabIndex = 4;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Customer
            // 
            this.Customer.HeaderText = "Customer";
            this.Customer.Name = "Customer";
            // 
            // Email
            // 
            this.Email.HeaderText = "Email";
            this.Email.Name = "Email";
            // 
            // TotalCost
            // 
            this.TotalCost.HeaderText = "Total Cost";
            this.TotalCost.Name = "TotalCost";
            // 
            // Confirmation_Number
            // 
            this.Confirmation_Number.HeaderText = "Confirmation Number";
            this.Confirmation_Number.Name = "Confirmation_Number";
            // 
            // Lower_Level_Seats
            // 
            this.Lower_Level_Seats.HeaderText = "Lower Level Seats";
            this.Lower_Level_Seats.Name = "Lower_Level_Seats";
            // 
            // Club_Level_Seats
            // 
            this.Club_Level_Seats.HeaderText = "Club Level Seats";
            this.Club_Level_Seats.Name = "Club_Level_Seats";
            // 
            // Upper_Deck_Seats
            // 
            this.Upper_Deck_Seats.HeaderText = "Upper Deck Seats";
            this.Upper_Deck_Seats.Name = "Upper_Deck_Seats";
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.Blue;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnClose.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnClose.Location = new System.Drawing.Point(713, 397);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 24);
            this.btnClose.TabIndex = 13;
            this.btnClose.Text = "CLOSE";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // frmAdmin_Panel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(849, 445);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lblSales);
            this.Controls.Add(this.label1);
            this.Name = "frmAdmin_Panel";
            this.Text = "Admin_Panel";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblSales;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblUDRemain;
        private System.Windows.Forms.Label lblCLRemain;
        private System.Windows.Forms.Label lblLLRemain;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox tbGuestLookup;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnGuestLookup;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Customer;
        private System.Windows.Forms.DataGridViewTextBoxColumn Email;
        private System.Windows.Forms.DataGridViewTextBoxColumn TotalCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn Confirmation_Number;
        private System.Windows.Forms.DataGridViewTextBoxColumn Lower_Level_Seats;
        private System.Windows.Forms.DataGridViewTextBoxColumn Club_Level_Seats;
        private System.Windows.Forms.DataGridViewTextBoxColumn Upper_Deck_Seats;
        private System.Windows.Forms.Button btnClose;
    }
}