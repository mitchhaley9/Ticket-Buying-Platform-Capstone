﻿namespace Capstone1._1
{
    partial class frmPurchase_Tickets
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnBuyTickets = new System.Windows.Forms.Button();
            this.cbUpperDeck = new System.Windows.Forms.ComboBox();
            this.cbClubLevel = new System.Windows.Forms.ComboBox();
            this.cbLowerLevel = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnBuyTickets);
            this.groupBox1.Controls.Add(this.cbUpperDeck);
            this.groupBox1.Controls.Add(this.cbClubLevel);
            this.groupBox1.Controls.Add(this.cbLowerLevel);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(28, 23);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(418, 250);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Select Tickets";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // btnBuyTickets
            // 
            this.btnBuyTickets.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnBuyTickets.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBuyTickets.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuyTickets.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnBuyTickets.Location = new System.Drawing.Point(163, 195);
            this.btnBuyTickets.Name = "btnBuyTickets";
            this.btnBuyTickets.Size = new System.Drawing.Size(119, 38);
            this.btnBuyTickets.TabIndex = 9;
            this.btnBuyTickets.Text = "Buy Tickets";
            this.btnBuyTickets.UseVisualStyleBackColor = false;
            this.btnBuyTickets.Click += new System.EventHandler(this.btnBuyTickets_Click);
            // 
            // cbUpperDeck
            // 
            this.cbUpperDeck.FormattingEnabled = true;
            this.cbUpperDeck.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cbUpperDeck.Location = new System.Drawing.Point(244, 144);
            this.cbUpperDeck.Name = "cbUpperDeck";
            this.cbUpperDeck.Size = new System.Drawing.Size(121, 21);
            this.cbUpperDeck.TabIndex = 8;
            this.cbUpperDeck.Text = "0";
            // 
            // cbClubLevel
            // 
            this.cbClubLevel.FormattingEnabled = true;
            this.cbClubLevel.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cbClubLevel.Location = new System.Drawing.Point(244, 90);
            this.cbClubLevel.Name = "cbClubLevel";
            this.cbClubLevel.Size = new System.Drawing.Size(121, 21);
            this.cbClubLevel.TabIndex = 7;
            this.cbClubLevel.Text = "0";
            // 
            // cbLowerLevel
            // 
            this.cbLowerLevel.FormattingEnabled = true;
            this.cbLowerLevel.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cbLowerLevel.Location = new System.Drawing.Point(244, 42);
            this.cbLowerLevel.Name = "cbLowerLevel";
            this.cbLowerLevel.Size = new System.Drawing.Size(121, 21);
            this.cbLowerLevel.TabIndex = 6;
            this.cbLowerLevel.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft JhengHei UI", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(29, 144);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(189, 24);
            this.label3.TabIndex = 5;
            this.label3.Text = "Upper Deck: $50.00";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft JhengHei UI", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(44, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(174, 24);
            this.label2.TabIndex = 4;
            this.label2.Text = "Club Level: $75.00";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft JhengHei UI", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(19, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(199, 24);
            this.label1.TabIndex = 3;
            this.label1.Text = "Lower Level: $125.00";
            // 
            // frmPurchase_Tickets
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(511, 370);
            this.Controls.Add(this.groupBox1);
            this.Name = "frmPurchase_Tickets";
            this.Text = "Purchase_Tickets";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbUpperDeck;
        private System.Windows.Forms.ComboBox cbClubLevel;
        private System.Windows.Forms.ComboBox cbLowerLevel;
        private System.Windows.Forms.Button btnBuyTickets;
    }
}