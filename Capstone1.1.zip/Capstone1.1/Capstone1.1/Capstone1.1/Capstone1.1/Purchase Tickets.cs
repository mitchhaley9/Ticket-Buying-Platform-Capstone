﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Capstone1._1
{
    public partial class frmPurchase_Tickets : Form
    {
        int LLSeats;
        int CLSeats;
        int UDSeats;


        public frmPurchase_Tickets()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
       


        private void btnBuyTickets_Click(object sender, EventArgs e)
        {
            
            LLSeats = int.Parse(cbLowerLevel.Text);
            CLSeats = int.Parse(cbClubLevel.Text);
            UDSeats = int.Parse(cbUpperDeck.Text);

            customer.LLseats = LLSeats;
            customer.CLseats = CLSeats;
            customer.UDseats = UDSeats;
          
            //soldoutChecker();
           if (LLSeats > 0 || CLSeats >0 || UDSeats >0)
            {
             
                customer.totalPrice = (LLSeats *125) + (CLSeats *75) + (UDSeats * 50);


            }

            emptyChecker();

        }
        private void emptyChecker()
        {
            if (customer.totalPrice==0)
            {
                MessageBox.Show("Select at least 1 ticket");
            }
           
            else
            {
                frmPurchase_Confirm goToConfirm = new frmPurchase_Confirm();
                this.Hide();
                goToConfirm.ShowDialog();
                this.Close();
            }
        }
    }
}
