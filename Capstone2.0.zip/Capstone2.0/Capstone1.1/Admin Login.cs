﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Capstone1._1
{
    public partial class frmAdmin_Login : Form
    {
        public frmAdmin_Login()
        {
            InitializeComponent();
        }

        private void btnAdminLogin_Click(object sender, EventArgs e)
        {
            if (tbAdminEmail.Text == "admin" && tbAdminPassword.Text == "bacs287")
            {
                frmAdmin_Panel goToPanel = new frmAdmin_Panel();
                this.Hide();
                goToPanel.ShowDialog();
                this.Close();
            }
            else
            {
                MessageBox.Show("Incorrect info");

                frmAdmin_Login goToAdmin = new frmAdmin_Login();
                this.Hide();
                goToAdmin.ShowDialog();
                this.Close();

            }

        }

        private void frmAdmin_Login_Load(object sender, EventArgs e)
        {

        }
    }
}
