﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;


namespace Capstone1._1
{
    public partial class frmPurchase_Confirm : Form
    {
        string CCNumber;
        string name;
        string CSV;
        bool errorCheck = false;

        public frmPurchase_Confirm()
        {
            InitializeComponent();
            lblTotalPrice.Text = ("Total Price: " + customer.totalPrice.ToString("C"));
        }
       
        private void Purchase_Confirm_Load(object sender, EventArgs e)
        {
            
        }

        private void btnFinalize_Click(object sender, EventArgs e)
        {
            errorCheck = false;
            //nameChecker();
            CCChecker();
            CSVChecker();
            emptyChecker();


            if (errorCheck=false)
            {


                customer.CCNumber = tbCCNumber.Text;
                customer.name = tbNameCard.Text;
                customer.CSV = tbSecurityCode.Text;

                //write to text file copy and pasted from create account
                string[] paymentInfo = new string[7];

                paymentInfo[0] = customer.name;
                paymentInfo[1] = customer.CCNumber;
                paymentInfo[2] = customer.CSV;
                paymentInfo[3] = customer.totalPrice.ToString("c");
                paymentInfo[4] = customer.LLseats.ToString();
                paymentInfo[5] = customer.CLseats.ToString();
                paymentInfo[6] = customer.UDseats.ToString();

                string accountload = string.Join(",", paymentInfo);
                File.AppendAllText("CustomerPayment.txt", accountload + "\r\n");
            }


        }

        private void CCChecker()
        {
            CCNumber = tbCCNumber.Text;

            if (CCNumber.Length <30)
            {
                MessageBox.Show("Credit card number too short, Must be 16 digits");
                errorCheck = true;
            }
            else if (CCNumber.Length >30)
            {
                MessageBox.Show("Credit card number too long, must be 16 digits");
                errorCheck = true;
            }
            else
            {
                errorCheck = false; 
            }

        }
        private void CSVChecker()
        {
            CSV = tbSecurityCode.Text;

            if (CSV.Length != 3)
            {
                MessageBox.Show("CSV must be 3 digits.");
                errorCheck = true;
            }
            else
            {
                errorCheck = false;
            }
        }
        private void nameChecker()
        {
            name = tbNameCard.Text;

            if (!System.Text.RegularExpressions.Regex.IsMatch(tbNameCard.Text, "^[a-zA-Z]"))
            {
                MessageBox.Show("This textbox accepts only alphabetical characters");
                tbNameCard.Text.Remove(tbNameCard.Text.Length - 1);
            }
        }
       private void emptyChecker()
        {
            if (tbNameCard.Text.Length ==0 || tbSecurityCode.Text.Length==0 || tbCCNumber.Text.Length==0)
            {
                MessageBox.Show("You Missed filling out a field.");
            }
        }

        private void lblTotalPrice_Click(object sender, EventArgs e)
        {

           
        }

        private void tbCCNumber_TextChanged(object sender, EventArgs e)
        {


        }
    }
}
