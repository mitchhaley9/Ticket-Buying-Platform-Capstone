﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capstone1._1
{
    class paymentInfo
    {
       
        public static int CCNumber
        {
            get; set;
        }
        public static string nameOnCard
        {
            get; set;
        }
        public static int securityCode
        {
            get; set;
        }
        
    }
}
