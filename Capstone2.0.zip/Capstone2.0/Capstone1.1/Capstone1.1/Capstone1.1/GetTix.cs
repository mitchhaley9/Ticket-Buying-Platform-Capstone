﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Capstone1._1
{


    public partial class frmGetTickets : Form
    {
        public frmGetTickets()
        {
            InitializeComponent();
        }

        private void frmGetTickets_Load(object sender, EventArgs e)
        {

        }

        private void btnGetTickets_Click(object sender, EventArgs e)
        {
            frmLogin goToUser = new frmLogin();
            this.Hide();
            goToUser.ShowDialog();
            this.Close();

        }

        private void btnAdmin_Click(object sender, EventArgs e)
        {
            frmAdmin_Login goToAdmin = new frmAdmin_Login();
            this.Hide();
            goToAdmin.ShowDialog();
            this.Close();

        }
    }
}
