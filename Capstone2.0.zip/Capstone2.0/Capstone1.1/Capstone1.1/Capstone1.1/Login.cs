﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;


namespace Capstone1._1
{
    
    public partial class frmLogin : Form
    {
        string[] userLoginInfo = File.ReadAllLines("usersaccounts.txt");
        
        public frmLogin()
        {
            InitializeComponent();
        }

        private void btnGetTickets_Click(object sender, EventArgs e)
        {
            bool validInfo = false;


            var verifyInfo = from info in userLoginInfo
                             let seperate = info.Split(',')
                             let email = seperate[1]
                             let password = seperate[3]
                             let age = seperate[2]
                             let name = seperate[0]

                             select new { email, password };


            foreach (var log in verifyInfo)
            {

                if (tbEmail.Text.Length == 0 || tbPassword.Text.Length == 0)
                {
                    MessageBox.Show("You must enter text into both the fields");
                }


                if (tbEmail.Text == log.email && tbPassword.Text == log.password)
                {
                    validInfo = true;
                    frmPurchase_Tickets goToBuyTix = new frmPurchase_Tickets();
                    this.Hide();
                    goToBuyTix.ShowDialog();
                    this.Close();
                }
            }

            if (validInfo == false)
            {
                MessageBox.Show("Enter a Valid Email and password");
            }
      

            
             }

        private void btnCreateAccount_Click(object sender, EventArgs e)
        {
            frmCreate_Account goToCreate = new frmCreate_Account();
            this.Hide();
            goToCreate.ShowDialog();
            this.Close();

        }

        private void frmLogin_Load(object sender, EventArgs e)
        {

        }
    }
}
