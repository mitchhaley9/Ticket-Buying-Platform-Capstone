﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;


namespace Capstone1._1
{
    public partial class frmPurchase_Confirm : Form
    {
        string CCNumber;
        string name;
        string CSV;
        bool errorCheck = false;

        public frmPurchase_Confirm()
        {
            InitializeComponent();
            lblTotalPrice.Text = ("Total Price: " + customer.totalPrice.ToString("C"));
        }
       
        private void Purchase_Confirm_Load(object sender, EventArgs e)
        {
            
        }

        private void btnFinalize_Click(object sender, EventArgs e)
        {
            errorCheck = false;
           
           


            Random r = new Random();
            int randNum = r.Next(1000, 9999);

            CCChecker();
            CSVChecker();
            emptyChecker();
            nameChecker();

            if (errorCheck==false)
            {
               

                customer.CCNumber = tbCCNumber.Text;
                customer.name = tbNameCard.Text;
                customer.CSV = tbSecurityCode.Text;
               

                //write to text file copy and pasted from create account
                string[] paymentInfo = new string[8];

                paymentInfo[0] = customer.name.ToUpper();
                paymentInfo[1] = customer.CCNumber;
                paymentInfo[2] = customer.CSV;
                paymentInfo[3] = customer.totalPrice.ToString();
                paymentInfo[4] = customer.LLseats.ToString();
                paymentInfo[5] = customer.CLseats.ToString();
                paymentInfo[6] = customer.UDseats.ToString();
                paymentInfo[7] = randNum.ToString();

                DialogResult result = (MessageBox.Show("Hello :" + customer.name + "\n" + "Please confirm you purchase of:  " + customer.totalPrice.ToString("c2") + "\n" + "Please click Yes to confirm your order", "Confirmation", MessageBoxButtons.YesNoCancel));

               


                if (result == DialogResult.Yes)
                {
                    MessageBox.Show("Thank you for your order!" + "\n" + "Your confirmation number is: " + randNum);
                    string accountload = string.Join(",", paymentInfo);
                    File.AppendAllText("CustomerPayment.txt", accountload + "\r\n");

                    this.Close();

                   
                }
            }
            else
            {
                frmPurchase_Confirm goToConfirm = new frmPurchase_Confirm();
                this.Hide();
                goToConfirm.ShowDialog();
                this.Close();
            }


        }

        private void CCChecker()
        {
            CCNumber = tbCCNumber.Text;

            if (CCNumber.Length !=16)
            {
                MessageBox.Show("Credit card number incorrect length, Must be 16 digits");
                errorCheck = true;
            }
           

        }
        private void CSVChecker()
        {
            CSV = tbSecurityCode.Text;

            if (CSV.Length != 3)
            {
                MessageBox.Show("CSV must be 3 digits.");
                errorCheck = true;
            }
           
        }
        private void nameChecker()
        {
            name = tbNameCard.Text;

            if (!System.Text.RegularExpressions.Regex.IsMatch(tbNameCard.Text, "^[a-zA-Z]"))
            {
                MessageBox.Show("This textbox accepts only alphabetical characters");
                tbNameCard.Text.Remove(tbNameCard.Text.Length - 1);
            }
        }
       private void emptyChecker()
        {
            if (tbNameCard.Text.Length ==0 || tbSecurityCode.Text.Length==0 || tbCCNumber.Text.Length==0)
            {
                MessageBox.Show("You Missed filling out a field.");
            }
        }

        private void lblTotalPrice_Click(object sender, EventArgs e)
        {

           
        }

        private void tbCCNumber_TextChanged(object sender, EventArgs e)
        {


        }
    }
}
