﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;

namespace Capstone1._1
{

   
    public partial class frmCreate_Account : Form
    {
        string name;
        string age;
        string password;
        string email;


        bool nameError = false; 
        bool ageError = false;
        bool emailFormat = false;
        bool noTextError = false;
        bool errorCheck = false;

        string[] userLoginInfo = File.ReadAllLines("usersaccounts.txt");

        public frmCreate_Account()
        {
            InitializeComponent();
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {

            emptyChecker();
            emailChecker();
            ageChecker();
       
           



            if (errorCheck == false)
            {


              
                //Rediirect, Need to write to text file and add error checking

                customer.name = tbName.Text;
                customer.age = int.Parse(tbAge.Text);
                customer.email = tbEmail.Text;


                //to the textfile below
                string[] usersaccount = new string[4];

                usersaccount[0] = customer.name.ToUpper();
                usersaccount[1] = customer.email;
                usersaccount[2] = customer.age.ToString();
                usersaccount[3] = tbPassword.Text;

                string accountload = string.Join(",", usersaccount);
                File.AppendAllText("usersaccounts.txt", accountload + "\r\n");

                frmPurchase_Tickets goToTix = new frmPurchase_Tickets();
                this.Hide();
                goToTix.ShowDialog();
                this.Close();
            }
            else
            {
                frmCreate_Account goToCreate = new frmCreate_Account();
                this.Hide();
                goToCreate.ShowDialog();
                this.Close();
            }

        }

        private void emailChecker()
        {
            string email = tbEmail.Text;

            Regex regex = new Regex ((@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$"));
            Match match = regex.Match(email);

            var verifyInfo = from info in userLoginInfo
                             let seperate = info.Split(',')
                             let fileEmail = seperate[1]
                             let password = seperate[3]
                             let age = seperate[2]
                             let name = seperate[0]

                             select new { name, fileEmail, password, age };

            if (match.Success)
            {
                emailFormat = false;
                //errorCheck = false;
            }
            else
            {
                errorCheck = true;
                emailFormat = true;
                MessageBox.Show("Invalid Email address entered", "Invalid Email");
            }

            foreach (var customer in verifyInfo)
            {
                if (email == customer.fileEmail)
                {
                    errorCheck = true;
                    MessageBox.Show("This Email already Exists");
                }
            }

        }
        private void emptyChecker()
        {
           
                name = tbName.Text;
                age = tbAge.Text;
                password = tbPassword.Text;
               email = tbEmail.Text;

            if (name.Length==0 || age.Length==0 || password.Length==0 || email.Length==0)
            {
                errorCheck = true;
                MessageBox.Show("A field is empty, fill out each field.");
            }
        }
        private void ageChecker ()
        {
           int age = int.Parse(tbAge.Text);

            if (age < 16)
            {
                errorCheck = true;
                MessageBox.Show("You need to be Over 16");
            }
        }




        private void tbPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void frmCreate_Account_Load(object sender, EventArgs e)
        {

        }
    }
}
