﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Capstone1._1
{
    public partial class frmAdmin_Panel : Form
    {
        string[] customers = File.ReadAllLines("CustomerPayment.txt");

        public frmAdmin_Panel()
        {
            double lltotalseats = 0;
            double cltotalseats = 0;
            double udtotalseats = 0;
            double TotalSales = customer.totalPrice;

            InitializeComponent();

            List<string> filePayload = File.ReadAllLines("CustomerPayment.txt").ToList();

                var datagridQuery = from name in customers
                                    let getdata = name.Split(',')
                                    let getname = getdata[0]
                                    let gettotalcost = getdata[3]
                                    let getConfirm = getdata[7]
                                    let ll = getdata[4]
                                    let cl = getdata[5]
                                    let ud = getdata[6]
                                    // let sales = getdata[3]
                                    select new { getname, gettotalcost, getConfirm, ll, cl, ud };


                // create a loop to add daat into data grid.  Also, use loop to compute total seats and total sales.
                foreach (var name in datagridQuery)
                {
                    //load data into data grid
                    dataGridView1.Rows.Add(name.getname, name.gettotalcost, name.getConfirm, name.ll, name.cl, name.ud);

                    //computer total seats purchased
                    lltotalseats += double.Parse(name.ll);
                    cltotalseats += double.Parse(name.cl);
                    udtotalseats += double.Parse(name.ud);
                    // TotalSales += double.Parse(name.sales);

                }

                lblLLRemain.Text = (200 - lltotalseats).ToString();
                lblCLRemain.Text = (75 - cltotalseats).ToString();
                lblUDRemain.Text = (200 - udtotalseats).ToString();
            // lblSales.Text = TotalSales.ToString("c2");

            //total sales
           lblSales.Text = ((lltotalseats * 125) + (cltotalseats * 75) + (udtotalseats * 50)).ToString("c");
           

        }
    
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmAdmin_Panel_Load(object sender, EventArgs e)
        {

        }

        private void lblSales_Click(object sender, EventArgs e)
        {
           
        }

        private void btnGuestLookup_Click(object sender, EventArgs e)
        {
            string confirmNum = tbGuestLookup.Text;

            var searchNameQuery = from name in customers
                                  let seatTotal = name.Split(',')
                                  let searchName = seatTotal[0].ToUpper()
                                  let amtCharged = seatTotal[1]
                                 
                                //  let confirm = seatTotal[10]
                                  select new { searchName, amtCharged, customer.LLseats, customer.CLseats, customer.UDseats, customer.confirmNum };

            foreach (var result in searchNameQuery)
            {
                if (confirmNum == result.confirmNum)
                {
                    MessageBox.Show("Found Confirmation number: " + result.confirmNum + "\n" + "Name:  " + result.searchName + "\n" + "Total Charge: $" + result.amtCharged + "\n", "Confirmation found");

                }

            }
            //highlights row.
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            try
            {
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    if (row.Cells[2].Value.ToString().Equals(confirmNum))
                    {
                        row.Selected = true;
                        //under slection view

                        //bring slelected row into focus
                        dataGridView1.FirstDisplayedScrollingRowIndex = dataGridView1.SelectedRows[0].Index;

                        break;
                    }


                }
            }
            catch
            {
                MessageBox.Show("Confirmation number does not exist!", "number now found");
            }
        }
    }
}
