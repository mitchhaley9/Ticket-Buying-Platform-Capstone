﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Capstone1._1
{
    public partial class frmPurchase_Tickets : Form
    {
        int LLSeats;
        int CLSeats;
        int UDSeats;
        bool soldout;
        string[] customers = File.ReadAllLines("CustomerPayment.txt");
        public frmPurchase_Tickets()
        {
            InitializeComponent();
            soldoutChecker();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
       


        private void btnBuyTickets_Click(object sender, EventArgs e)
        {
            
            LLSeats = int.Parse(cbLowerLevel.Text);
            CLSeats = int.Parse(cbClubLevel.Text);
            UDSeats = int.Parse(cbUpperDeck.Text);

            customer.LLseats = LLSeats;
            customer.CLseats = CLSeats;
            customer.UDseats = UDSeats;
          
            
           if (LLSeats > 0 || CLSeats >0 || UDSeats >0)
            {
             
                customer.totalPrice = (LLSeats *125) + (CLSeats *75) + (UDSeats * 50);
            }
            soldoutChecker();
            emptyChecker();

        }
        private void emptyChecker()
        {
            if (customer.totalPrice==0)
            {
                MessageBox.Show("Select at least 1 ticket");
            }
           
            else
            {
                frmPurchase_Confirm goToConfirm = new frmPurchase_Confirm();
                this.Hide();
                goToConfirm.ShowDialog();
                this.Close();
            }
        }

        private void frmPurchase_Tickets_Load(object sender, EventArgs e)
        {

        }

        private void soldoutChecker()
        {
            double llSeats = 0;
            double clSeats = 0;
            double udSeats = 0;

            
                var getSeatsQuery = from name in customers
                                    let seatTotal = name.Split(',')
                                    let ll = seatTotal[4]
                                    let cl = seatTotal[5]
                                    let ud = seatTotal[6]
                                    //     let sales = seatTotal[6]
                                    select new { ll, cl, ud, };

                foreach (var total in getSeatsQuery)
                {
                    llSeats += double.Parse(total.ll);
                    clSeats += double.Parse(total.cl);
                    udSeats += double.Parse(total.ud);

                }

            


            double llTotal = 0;
            double clTotal = 0;
            double udTotal = 0;

            llTotal = 200 - llSeats - double.Parse(cbLowerLevel.Text);
            clTotal = 75 - clSeats - double.Parse(cbClubLevel.Text);
            udTotal = 200 - udSeats - double.Parse(cbUpperDeck.Text);


            if (llTotal<= 0)
            {
                lblLL.Text = "Sold Out";
                lblLL.ForeColor = Color.Red;
                cbLowerLevel.Visible = false;
                soldout = true;
            }
            if (clTotal <= 0)
            {
                lblCL.Text = "Sold Out";
                lblCL.ForeColor = Color.Red;
                cbClubLevel.Visible = false;
                soldout = true;
            }
            if (udTotal <= 0)
            {
                lblUD.Text = "Sold Out";
                lblUD.ForeColor = Color.Red;
                cbUpperDeck.Visible = false;
                soldout = true;
            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
