﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capstone1._1
{
    class customer
    {
        public static string name
        {
            get; set;
        }
        public static string email
        {
            get; set;
        }
        public static int age
        {
            get; set;
        }
        public static string password
        {
            get; set;
        }
        public static int LLseats
        {
            get; set;
        }
        public static int CLseats
        {
            get; set;
        }
        public static int UDseats
        {
            get; set;
        }
        public static double totalPrice
        {
            get; set;
        }
        public static string CCNumber
        {
            get; set;
        }
        public static string CSV
        {
            get; set;
        }
        public static string confirmNum
            {
            get; set;
            }

    }
}
